## puppet-dmlite module

This is the puppet-dmlite module, it configures the dmlite component and its plugins.
It's the base puppet module for the configuration of Data Management components developed at CERN , IT-SDC-ID section

###CI builds

[![Build Status](https://travis-ci.org/cern-it-sdc-id/puppet-dmlite.svg?branch=master)](https://travis-ci.org/cern-it-sdc-id/puppet-dmlite)

### License
ASL 2.0

### Contact
Andrea Manzi <andrea.manzi@cern.ch>

## Support
Tickets and issues at our [cern-it-sdc-id site](https://github.com/cern-it-sdc-id)
